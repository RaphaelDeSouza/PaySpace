﻿using Payspace.Assesment.ViewModel;
using System.Collections.Generic;

namespace Payspace.Assesment.Interface
{
    public interface ICalculator
    {
        CalculationResult Calculation(string PostalCode, double AnnualIncome);
        IEnumerable<PostalCode> PostalCodes();
    }
}
