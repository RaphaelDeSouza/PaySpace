﻿using Microsoft.EntityFrameworkCore;
using Payspace.Assesment.Entities;

namespace Payspace.Assesment.Repository
{
    public class CalculatorContext : DbContext
    {
        public CalculatorContext(string ConnectionString) : base(GetOptions(ConnectionString))
        {

        }

        private static DbContextOptions GetOptions(string connectionString)
        {
            return SqlServerDbContextOptionsExtensions.UseSqlServer(new DbContextOptionsBuilder(), connectionString).Options;
        }

        public CalculatorContext(DbContextOptions<CalculatorContext> options) : base(options)
        {
        }
        public DbSet<PostalCode> PostalCode { get; set; }
        public DbSet<Calculations> Calculations { get; set; }
        public DbSet<AuditResults> AuditResults { get; set; }
    }
}
