﻿namespace Payspace.Assesment.ViewModel
{
    public class PostalCode
    {
        public string Code { get; set; }
        public string CalcType { get; set; }
    }
}
