﻿using Microsoft.AspNetCore.Mvc.Filters;

namespace Payspace.Assesment
{
    public class RequestAction : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            
        }
        public override void OnResultExecuted(ResultExecutedContext context)
        {
            
        }
    }
}
