﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Payspace.Assesment.Repository;

namespace Payspace.Assesment
{
    public static partial class MvcExtensions
    {
        public static IMvcBuilder AddCalculator(this IMvcBuilder sender, IConfiguration Configuration, IServiceCollection services)
        {
            sender.Services.AddDbContextPool<CalculatorContext>(options => options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"), option => option.EnableRetryOnFailure()));
            sender.AddApplicationPart(typeof(Controller.CalculatorController).Assembly);
            return sender;
        }
    }
}
