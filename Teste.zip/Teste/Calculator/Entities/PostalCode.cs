﻿using Payspace.Assesment.Enumerations;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Payspace.Assesment.Entities
{
    public class PostalCode
    {
        [Key]
        public string Code { get; set; }

        [Column(TypeName = "bigint")]
        public ECalculationType CalcType { get; set; }
    }
}
