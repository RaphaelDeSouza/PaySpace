﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Payspace.Assesment.Entities
{
    public class AuditResults
    {
        [Key]
        public long AuditID { get; set; }
        public string PostalCode { get; set; }
        public double AnnualIncome { get; set; }
        public DateTime RequestedDate { get; set; }
        public double Tax { get; set; }
    }
}
