﻿using System.ComponentModel.DataAnnotations;

namespace Payspace.Assesment.Entities
{
    public class Calculations
    {
        [Key]
        public long CalculationID { get; set; }

        public double Rate { get; set; }

        public double From { get; set; }

        public double To { get; set; }
    }
}
