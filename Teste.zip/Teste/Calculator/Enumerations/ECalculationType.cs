﻿namespace Payspace.Assesment.Enumerations
{
    public enum ECalculationType
    {
        Progressive = 0,
        FlatValue = 1,
        FlatRate = 2,
    }
}
